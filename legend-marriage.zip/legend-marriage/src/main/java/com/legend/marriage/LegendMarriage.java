package com.legend.marriage;

import com.legend.marriage.command.MarriageCommand;
import com.legend.marriage.config.MessageManager;
import com.legend.marriage.data.Database;
import com.legend.marriage.economy.EconomyBridge;
import com.legend.marriage.gui.GuiListener;
import com.legend.marriage.gui.MarriageGui;
import com.legend.marriage.marriage.MarriageManager;
import com.legend.marriage.model.WifeRegistry;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class LegendMarriage extends JavaPlugin {

    private Database database;
    private EconomyBridge economy;
    private MessageManager messages;
    private WifeRegistry wives;
    private MarriageManager marriages;
    private MarriageGui gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("messages.yml", false);
        saveResource("wives.yml", false);

        database = new Database(new File(getDataFolder(), "legend-marriage.db"), getLogger());
        database.open();
        economy = new EconomyBridge(this);
        messages = new MessageManager(this);
        wives = new WifeRegistry();
        marriages = new MarriageManager(this, database);
        gui = new MarriageGui(this);
        reloadAll();

        MarriageCommand command = new MarriageCommand(this);
        PluginCommand pluginCommand = getCommand("زواج");
        if (pluginCommand != null) {
            pluginCommand.setExecutor(command);
            pluginCommand.setTabCompleter(command);
        }
        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getLogger().info("Legend Marriage enabled. Economy: " + (economy.available() ? "Vault" : "none"));
    }

    @Override
    public void onDisable() {
        if (database != null) {
            database.close();
        }
    }

    public void reloadAll() {
        reloadConfig();
        economy.setup();
        messages.load();
        wives.load(new File(getDataFolder(), "wives.yml"));
        marriages.reloadSettings();
    }

    public Database database() { return database; }
    public EconomyBridge economy() { return economy; }
    public MessageManager messages() { return messages; }
    public WifeRegistry wives() { return wives; }
    public MarriageManager marriages() { return marriages; }
    public MarriageGui gui() { return gui; }
}
