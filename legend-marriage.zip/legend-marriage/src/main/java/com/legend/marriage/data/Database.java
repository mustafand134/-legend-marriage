package com.legend.marriage.data;

import com.legend.marriage.model.MarriageRecord;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/** SQLite storage. Writes run on a single background thread; reads happen at startup. */
public final class Database {

    @FunctionalInterface
    private interface SqlTask {
        void run(Connection c) throws SQLException;
    }

    private final File file;
    private final Logger log;
    private Connection conn;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "LegendMarriage-DB");
        t.setDaemon(true);
        return t;
    });

    public Database(File file, Logger log) {
        this.file = file;
        this.log = log;
    }

    public void open() {
        file.getParentFile().mkdirs();
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
            try (Statement st = conn.createStatement()) {
                st.executeUpdate("CREATE TABLE IF NOT EXISTS relationships ("
                        + "player TEXT NOT NULL, target TEXT NOT NULL, points INTEGER NOT NULL, "
                        + "PRIMARY KEY(player, target))");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS marriages ("
                        + "player TEXT PRIMARY KEY, spouse TEXT NOT NULL, immediate_paid REAL NOT NULL, "
                        + "deferred_debt REAL NOT NULL, married_at INTEGER NOT NULL)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS history ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, player TEXT NOT NULL, event TEXT NOT NULL, "
                        + "amount REAL NOT NULL, at INTEGER NOT NULL)");
            }
        } catch (SQLException e) {
            log.log(Level.SEVERE, "Could not open the database", e);
        }
    }

    public synchronized Map<UUID, Map<String, Integer>> loadRelationships() {
        Map<UUID, Map<String, Integer>> result = new HashMap<>();
        if (conn == null) {
            return result;
        }
        try (PreparedStatement ps = conn.prepareStatement("SELECT player, target, points FROM relationships");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                UUID player = UUID.fromString(rs.getString("player"));
                result.computeIfAbsent(player, k -> new HashMap<>())
                        .put(rs.getString("target"), rs.getInt("points"));
            }
        } catch (SQLException e) {
            log.log(Level.SEVERE, "Could not load relationships", e);
        }
        return result;
    }

    public synchronized Map<UUID, MarriageRecord> loadMarriages() {
        Map<UUID, MarriageRecord> result = new HashMap<>();
        if (conn == null) {
            return result;
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT player, spouse, immediate_paid, deferred_debt, married_at FROM marriages");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                UUID player = UUID.fromString(rs.getString("player"));
                result.put(player, new MarriageRecord(player, rs.getString("spouse"),
                        rs.getDouble("immediate_paid"), rs.getDouble("deferred_debt"), rs.getLong("married_at")));
            }
        } catch (SQLException e) {
            log.log(Level.SEVERE, "Could not load marriages", e);
        }
        return result;
    }

    public void saveRelationship(UUID player, String target, int points) {
        submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO relationships(player, target, points) VALUES(?,?,?) "
                            + "ON CONFLICT(player, target) DO UPDATE SET points = excluded.points")) {
                ps.setString(1, player.toString());
                ps.setString(2, target);
                ps.setInt(3, points);
                ps.executeUpdate();
            }
        });
    }

    public void saveMarriage(MarriageRecord r) {
        submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO marriages(player, spouse, immediate_paid, deferred_debt, married_at) "
                            + "VALUES(?,?,?,?,?) ON CONFLICT(player) DO UPDATE SET spouse = excluded.spouse, "
                            + "immediate_paid = excluded.immediate_paid, deferred_debt = excluded.deferred_debt, "
                            + "married_at = excluded.married_at")) {
                ps.setString(1, r.player().toString());
                ps.setString(2, r.spouse());
                ps.setDouble(3, r.immediatePaid());
                ps.setDouble(4, r.deferredDebt());
                ps.setLong(5, r.marriedAt());
                ps.executeUpdate();
            }
        });
    }

    public void deleteMarriage(UUID player) {
        submit(c -> {
            try (PreparedStatement ps = c.prepareStatement("DELETE FROM marriages WHERE player = ?")) {
                ps.setString(1, player.toString());
                ps.executeUpdate();
            }
        });
    }

    public void addHistory(UUID player, String event, double amount) {
        submit(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO history(player, event, amount, at) VALUES(?,?,?,?)")) {
                ps.setString(1, player.toString());
                ps.setString(2, event);
                ps.setDouble(3, amount);
                ps.setLong(4, System.currentTimeMillis());
                ps.executeUpdate();
            }
        });
    }

    public void close() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                log.warning("Database writes did not finish in time");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        synchronized (this) {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                log.log(Level.WARNING, "Error closing database", e);
            }
        }
    }

    private void submit(SqlTask task) {
        executor.execute(() -> {
            synchronized (this) {
                if (conn == null) {
                    return;
                }
                try {
                    task.run(conn);
                } catch (SQLException e) {
                    log.log(Level.SEVERE, "Database write failed", e);
                }
            }
        });
    }
}
