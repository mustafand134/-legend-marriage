package com.legend.marriage.model;

import org.bukkit.Material;

import java.util.Set;

public record WifeProfile(
        String id,
        String name,
        String personality,
        int age,
        String description,
        String greeting,
        Material icon,
        Set<Material> favoriteGifts,
        Set<Material> dislikedGifts,
        double minImmediate,
        double maxImmediate,
        double minDeferred,
        double maxDeferred
) {}
