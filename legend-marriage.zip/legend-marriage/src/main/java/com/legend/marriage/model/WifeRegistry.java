package com.legend.marriage.model;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.Collection;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class WifeRegistry {

    private final Map<String, WifeProfile> wives = new LinkedHashMap<>();

    public void load(File file) {
        wives.clear();
        if (!file.exists()) {
            return;
        }
        ConfigurationSection root = YamlConfiguration.loadConfiguration(file).getConfigurationSection("wives");
        if (root == null) {
            return;
        }
        for (String rawId : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(rawId);
            if (s == null) {
                continue;
            }
            String id = rawId.toLowerCase(Locale.ROOT);
            Material icon = Material.matchMaterial(s.getString("icon", "PINK_TULIP"));
            if (icon == null) {
                icon = Material.PINK_TULIP;
            }
            wives.put(id, new WifeProfile(
                    id,
                    s.getString("name", rawId),
                    s.getString("personality", "friendly"),
                    s.getInt("age", 25),
                    s.getString("description", ""),
                    s.getString("greeting", ""),
                    icon,
                    materials(s.getStringList("favorite-gifts")),
                    materials(s.getStringList("disliked-gifts")),
                    s.getDouble("min-immediate", 0),
                    s.getDouble("max-immediate", 0),
                    s.getDouble("min-deferred", 0),
                    s.getDouble("max-deferred", 0)
            ));
        }
    }

    public WifeProfile get(String id) {
        if (id == null) {
            return null;
        }
        return wives.get(id.toLowerCase(Locale.ROOT));
    }

    public Collection<WifeProfile> all() {
        return wives.values();
    }

    private static Set<Material> materials(List<String> names) {
        Set<Material> set = EnumSet.noneOf(Material.class);
        for (String name : names) {
            Material m = Material.matchMaterial(name);
            if (m != null) {
                set.add(m);
            }
        }
        return set;
    }
}
