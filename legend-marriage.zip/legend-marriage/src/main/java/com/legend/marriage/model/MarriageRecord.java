package com.legend.marriage.model;

import java.util.UUID;

/**
 * One side of a marriage. spouse is a wife id for NPC marriages,
 * or the partner's UUID string for player marriages.
 * deferredDebt is the deferred dowry (مهر مؤخر) owed by this side.
 */
public record MarriageRecord(UUID player, String spouse, double immediatePaid, double deferredDebt, long marriedAt) {

    public boolean npcSpouse() {
        try {
            UUID.fromString(spouse);
            return false;
        } catch (IllegalArgumentException e) {
            return true;
        }
    }
}
