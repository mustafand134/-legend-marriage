package com.legend.marriage.gui;

import com.legend.marriage.LegendMarriage;
import com.legend.marriage.config.MessageManager;
import com.legend.marriage.marriage.MarriageManager;
import com.legend.marriage.marriage.MarriageManager.GiftResult;
import com.legend.marriage.model.MarriageRecord;
import com.legend.marriage.model.WifeProfile;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public final class MarriageGui {

    private final LegendMarriage plugin;

    public MarriageGui(LegendMarriage plugin) {
        this.plugin = plugin;
    }

    private MessageManager msg() {
        return plugin.messages();
    }

    public void openMain(Player p) {
        GuiHolder holder = new GuiHolder(GuiHolder.Type.MAIN, "");
        Inventory inv = Bukkit.createInventory(holder, 27, msg().get("gui.main-title"));
        holder.bind(inv);
        inv.setItem(11, item(Material.BOOK, msg().get("gui.search"), List.of(msg().get("gui.search-hint"))));
        inv.setItem(13, item(Material.PINK_TULIP, msg().get("gui.own"), List.of()));
        inv.setItem(15, item(Material.PAPER, msg().get("gui.help"), List.of()));
        p.openInventory(inv);
    }

    public void openSearch(Player p) {
        GuiHolder holder = new GuiHolder(GuiHolder.Type.SEARCH, "");
        Inventory inv = Bukkit.createInventory(holder, 54, msg().get("gui.search-title"));
        holder.bind(inv);
        List<WifeProfile> list = new ArrayList<>(plugin.wives().all());
        for (int i = 0; i < Math.min(list.size(), 45); i++) {
            WifeProfile w = list.get(i);
            inv.setItem(i, item(w.icon(), MessageManager.color("&e" + w.name()), searchLore(p, w)));
        }
        inv.setItem(49, item(Material.ARROW, msg().get("gui.back"), List.of()));
        p.openInventory(inv);
    }

    private List<String> searchLore(Player p, WifeProfile w) {
        List<String> lore = new ArrayList<>();
        lore.add(msg().get("personality." + w.personality()));
        lore.add(msg().get("gui.age", "age", String.valueOf(w.age())));
        lore.add(msg().get("gui.dowry-range",
                "imm_min", MessageManager.fmt(w.minImmediate()), "imm_max", MessageManager.fmt(w.maxImmediate()),
                "def_min", MessageManager.fmt(w.minDeferred()), "def_max", MessageManager.fmt(w.maxDeferred())));
        String levelKey = plugin.marriages().levelKey(p.getUniqueId(), w.id(), false);
        lore.add(msg().get("gui.level", "level", msg().get("level." + levelKey),
                "points", String.valueOf(plugin.marriages().points(p.getUniqueId(), w.id()))));
        lore.add(MessageManager.color(w.description()));
        lore.add(msg().get("gui.details-hint"));
        return lore;
    }

    public void openWifeDetail(Player p, WifeProfile w) {
        GuiHolder holder = new GuiHolder(GuiHolder.Type.WIFE_DETAIL, w.id());
        Inventory inv = Bukkit.createInventory(holder, 27, msg().get("gui.wife-title"));
        holder.bind(inv);

        inv.setItem(11, item(Material.DIAMOND, msg().get("gui.propose"), List.of(
                msg().get("gui.propose-hint"),
                msg().get("gui.dowry-range",
                        "imm_min", MessageManager.fmt(w.minImmediate()), "imm_max", MessageManager.fmt(w.maxImmediate()),
                        "def_min", MessageManager.fmt(w.minDeferred()), "def_max", MessageManager.fmt(w.maxDeferred())))));

        String favorites = w.favoriteGifts().stream()
                .map(m -> m.name().toLowerCase().replace('_', ' '))
                .collect(Collectors.joining(", "));
        List<String> info = new ArrayList<>();
        info.add(MessageManager.color("&f\"" + w.greeting() + "\""));
        info.add(MessageManager.color(w.description()));
        info.add(msg().get("personality." + w.personality()));
        info.add(msg().get("gui.age", "age", String.valueOf(w.age())));
        info.add(msg().get("gui.favorites", "list", favorites));
        inv.setItem(13, item(w.icon(), MessageManager.color("&e" + w.name()), info));

        inv.setItem(15, item(Material.CAKE, msg().get("gui.gift"), List.of(msg().get("gui.gift-hint"))));
        inv.setItem(22, item(Material.ARROW, msg().get("gui.back"), List.of()));
        p.openInventory(inv);
    }

    public void openOwn(Player p) {
        GuiHolder holder = new GuiHolder(GuiHolder.Type.OWN, "");
        Inventory inv = Bukkit.createInventory(holder, 27, msg().get("gui.own-title"));
        holder.bind(inv);
        MarriageRecord rec = plugin.marriages().get(p.getUniqueId());
        if (rec == null) {
            inv.setItem(13, item(Material.BARRIER, msg().get("gui.none"), List.of()));
        } else {
            UUID id = p.getUniqueId();
            String name = plugin.marriages().displayName(rec.spouse());
            int pts = plugin.marriages().points(id, rec.spouse());
            String level = plugin.marriages().levelKey(id, rec.spouse(), true);
            List<String> lore = new ArrayList<>();
            lore.add(msg().get("gui.level", "level", msg().get("level." + level), "points", String.valueOf(pts)));
            lore.add(msg().get("gui.immediate-paid", "amount", MessageManager.fmt(rec.immediatePaid())));
            lore.add(msg().get("gui.deferred-debt", "amount", MessageManager.fmt(rec.deferredDebt())));
            inv.setItem(13, item(Material.PINK_TULIP, MessageManager.color("&d" + name), lore));
            inv.setItem(15, item(Material.CAKE, msg().get("gui.gift"), List.of(msg().get("gui.gift-hint"))));
        }
        inv.setItem(22, item(Material.ARROW, msg().get("gui.back"), List.of()));
        p.openInventory(inv);
    }

    public void handleClick(Player p, GuiHolder holder, int slot) {
        switch (holder.getType()) {
            case MAIN -> {
                if (slot == 11) openSearch(p);
                else if (slot == 13) openOwn(p);
                else if (slot == 15) msg().sendList(p, "help");
            }
            case SEARCH -> {
                if (slot == 49) {
                    openMain(p);
                } else if (slot < 45) {
                    List<WifeProfile> list = new ArrayList<>(plugin.wives().all());
                    if (slot < list.size()) openWifeDetail(p, list.get(slot));
                }
            }
            case WIFE_DETAIL -> {
                WifeProfile w = plugin.wives().get(holder.getData());
                if (w == null) return;
                if (slot == 11) {
                    proposeNpc(p, w);
                } else if (slot == 15) {
                    gift(p, w.id(), w);
                } else if (slot == 22) {
                    openSearch(p);
                }
            }
            case OWN -> {
                MarriageRecord rec = plugin.marriages().get(p.getUniqueId());
                if (slot == 15 && rec != null) {
                    gift(p, rec.spouse(), plugin.wives().get(rec.spouse()));
                } else if (slot == 22) {
                    openMain(p);
                }
            }
        }
    }

    private void proposeNpc(Player p, WifeProfile w) {
        MarriageManager.Result r = plugin.marriages().proposeNpc(p, w, w.minImmediate(), w.minDeferred());
        if (r == MarriageManager.Result.OK) {
            msg().send(p, "marry.npc", "wife", w.name(),
                    "imm", MessageManager.fmt(w.minImmediate()), "def", MessageManager.fmt(w.minDeferred()));
            p.closeInventory();
        } else {
            msg().sendResult(p, r);
        }
    }

    private void gift(Player p, String key, WifeProfile w) {
        GiftResult g = plugin.marriages().gift(p, key, w);
        msg().sendGift(p, g, plugin.marriages().displayName(key));
    }

    private ItemStack item(Material mat, String name, List<String> lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(lore);
            it.setItemMeta(meta);
        }
        return it;
    }
}
