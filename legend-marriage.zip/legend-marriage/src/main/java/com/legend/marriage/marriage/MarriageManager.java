package com.legend.marriage.marriage;

import com.legend.marriage.LegendMarriage;
import com.legend.marriage.data.Database;
import com.legend.marriage.model.MarriageRecord;
import com.legend.marriage.model.Proposal;
import com.legend.marriage.model.WifeProfile;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Core marriage rules: proposals, dowry, gifts, relationship points and divorce. */
public final class MarriageManager {

    public enum Result {
        OK("ok"),
        NO_ECONOMY("err.no-economy"),
        SELF("err.self"),
        ALREADY_MARRIED("err.already-married"),
        TARGET_MARRIED("err.target-married"),
        NOT_MARRIED("err.not-married"),
        WIFE_NOT_FOUND("err.wife-not-found"),
        RELATIONSHIP_LOW("err.relationship-low"),
        DOWRY_LOW("err.dowry-low"),
        DOWRY_HIGH("err.dowry-high"),
        DEFERRED_RANGE("err.deferred-range"),
        NO_FUNDS("err.no-funds"),
        NO_PROPOSAL("err.no-proposal"),
        PROPOSAL_EXPIRED("err.proposal-expired"),
        GIFT_COOLDOWN("err.gift-cooldown"),
        NO_ITEM("err.no-item");

        private final String key;

        Result(String key) {
            this.key = key;
        }

        public String getKey() {
            return key;
        }
    }

    /** reaction: favorite | normal | disliked. levelKey is the relationship level after the gift. */
    public record GiftResult(Result result, String reaction, int delta, int points, boolean levelUp, String levelKey) {}

    private final LegendMarriage plugin;
    private final Database db;
    private final Map<UUID, Map<String, Integer>> relationships = new ConcurrentHashMap<>();
    private final Map<UUID, MarriageRecord> marriages = new ConcurrentHashMap<>();
    private final Map<UUID, Proposal> proposals = new ConcurrentHashMap<>();
    private final Map<String, Long> giftCooldowns = new ConcurrentHashMap<>();
    private final Map<String, Integer> levels = new LinkedHashMap<>();

    private int minPointsToPropose;
    private int maxPoints;
    private int favPoints;
    private int normalPoints;
    private int disPoints;
    private long cooldownMillis;
    private long expireMillis;
    private double defaultImmediate;
    private double defaultDeferred;
    private boolean requireEconomy;

    public MarriageManager(LegendMarriage plugin, Database db) {
        this.plugin = plugin;
        this.db = db;
        relationships.putAll(db.loadRelationships());
        marriages.putAll(db.loadMarriages());
    }

    public void reloadSettings() {
        var cfg = plugin.getConfig();
        minPointsToPropose = cfg.getInt("relationship.min-points-to-propose", 30);
        maxPoints = cfg.getInt("relationship.max-points", 300);
        cooldownMillis = cfg.getLong("relationship.gift-cooldown-seconds", 60) * 1000L;
        favPoints = cfg.getInt("relationship.points.favorite-gift", 15);
        normalPoints = cfg.getInt("relationship.points.normal-gift", 5);
        disPoints = cfg.getInt("relationship.points.disliked-gift", -5);
        expireMillis = cfg.getLong("proposal-expire-seconds", 120) * 1000L;
        defaultImmediate = cfg.getDouble("dowry.default-immediate-player", 500);
        defaultDeferred = cfg.getDouble("dowry.default-deferred-player", 0);
        requireEconomy = cfg.getBoolean("economy.required", true);
        levels.clear();
        ConfigurationSection sec = cfg.getConfigurationSection("relationship.levels");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                levels.put(key, sec.getInt(key));
            }
        }
    }

    public double defaultImmediate() { return defaultImmediate; }
    public double defaultDeferred() { return defaultDeferred; }

    public boolean isMarried(UUID player) { return marriages.containsKey(player); }
    public MarriageRecord get(UUID player) { return marriages.get(player); }
    public Proposal pendingProposal(UUID target) { return proposals.get(target); }

    public int points(UUID player, String target) {
        Map<String, Integer> m = relationships.get(player);
        return m == null ? 0 : m.getOrDefault(target, 0);
    }

    private boolean isSpouse(UUID player, String key) {
        MarriageRecord r = marriages.get(player);
        return r != null && r.spouse().equals(key);
    }

    /** Relationship level key (see relationship.levels in config.yml). */
    public String levelKey(UUID player, String target, boolean married) {
        int pts = points(player, target);
        if (married) {
            return pts >= levelMin("loving-family") ? "loving-family" : "married";
        }
        String best = "stranger";
        int bestMin = Integer.MIN_VALUE;
        for (Map.Entry<String, Integer> e : levels.entrySet()) {
            String k = e.getKey();
            if (k.equals("married") || k.equals("loving-family")) {
                continue;
            }
            if (pts >= e.getValue() && e.getValue() > bestMin) {
                best = k;
                bestMin = e.getValue();
            }
        }
        return best;
    }

    private int levelMin(String key) {
        return levels.getOrDefault(key, Integer.MAX_VALUE);
    }

    public String displayName(String key) {
        WifeProfile w = plugin.wives().get(key);
        if (w != null) {
            return w.name();
        }
        try {
            String n = Bukkit.getOfflinePlayer(UUID.fromString(key)).getName();
            return n != null ? n : key;
        } catch (IllegalArgumentException e) {
            return key;
        }
    }

    private int addPoints(UUID player, String target, int delta) {
        int next = Math.max(0, Math.min(maxPoints, points(player, target) + delta));
        relationships.computeIfAbsent(player, k -> new HashMap<>()).put(target, next);
        db.saveRelationship(player, target, next);
        return next;
    }

    private void saveMarriage(MarriageRecord record) {
        marriages.put(record.player(), record);
        db.saveMarriage(record);
    }

    private boolean canAfford(OfflinePlayer player, double amount) {
        if (amount <= 0) {
            return true;
        }
        if (!plugin.economy().available()) {
            return !requireEconomy;
        }
        return plugin.economy().has(player, amount);
    }

    private boolean pay(OfflinePlayer player, double amount) {
        if (amount <= 0) {
            return true;
        }
        if (!plugin.economy().available()) {
            return !requireEconomy;
        }
        return plugin.economy().withdraw(player, amount);
    }

    /** Marries a wife NPC. The wife's family (father) approves automatically if the terms are within range. */
    public Result proposeNpc(Player p, WifeProfile wife, double imm, double def) {
        if (requireEconomy && !plugin.economy().available()) return Result.NO_ECONOMY;
        if (isMarried(p.getUniqueId())) return Result.ALREADY_MARRIED;
        if (points(p.getUniqueId(), wife.id()) < minPointsToPropose) return Result.RELATIONSHIP_LOW;
        if (imm < wife.minImmediate()) return Result.DOWRY_LOW;
        if (imm > wife.maxImmediate()) return Result.DOWRY_HIGH;
        if (def < wife.minDeferred() || def > wife.maxDeferred()) return Result.DEFERRED_RANGE;
        if (!canAfford(p, imm) || !pay(p, imm)) return Result.NO_FUNDS;

        saveMarriage(new MarriageRecord(p.getUniqueId(), wife.id(), imm, def, System.currentTimeMillis()));
        db.addHistory(p.getUniqueId(), "married-npc:" + wife.id(), imm);
        return Result.OK;
    }

    /** Sends a player-to-player proposal. The target must accept with /زواج قبول. */
    public Result proposePlayer(Player p, Player target, double imm, double def) {
        if (p.getUniqueId().equals(target.getUniqueId())) return Result.SELF;
        if (requireEconomy && !plugin.economy().available()) return Result.NO_ECONOMY;
        if (isMarried(p.getUniqueId())) return Result.ALREADY_MARRIED;
        if (isMarried(target.getUniqueId())) return Result.TARGET_MARRIED;
        if (points(p.getUniqueId(), target.getUniqueId().toString()) < minPointsToPropose) return Result.RELATIONSHIP_LOW;
        if (imm < 0 || def < 0) return Result.DOWRY_LOW;
        if (!canAfford(p, imm)) return Result.NO_FUNDS;

        long expires = System.currentTimeMillis() + expireMillis;
        proposals.put(target.getUniqueId(), new Proposal(p.getUniqueId(), imm, def, expires));
        return Result.OK;
    }

    public Result accept(Player target) {
        UUID tid = target.getUniqueId();
        Proposal pr = proposals.remove(tid);
        if (pr == null) return Result.NO_PROPOSAL;
        if (System.currentTimeMillis() > pr.expiresAt()) return Result.PROPOSAL_EXPIRED;
        if (isMarried(tid)) return Result.TARGET_MARRIED;
        if (isMarried(pr.proposer())) return Result.ALREADY_MARRIED;

        OfflinePlayer proposer = Bukkit.getOfflinePlayer(pr.proposer());
        if (!pay(proposer, pr.immediate())) return Result.NO_FUNDS;
        if (pr.immediate() > 0 && plugin.economy().available()) {
            plugin.economy().deposit(target, pr.immediate());
        }

        long now = System.currentTimeMillis();
        // The husband (proposer) owes the deferred dowry; the wife's side owes nothing.
        saveMarriage(new MarriageRecord(pr.proposer(), tid.toString(), pr.immediate(), pr.deferred(), now));
        saveMarriage(new MarriageRecord(tid, pr.proposer().toString(), pr.immediate(), 0, now));
        db.addHistory(tid, "married-player:" + pr.proposer(), pr.immediate());
        db.addHistory(pr.proposer(), "married-player:" + tid, pr.immediate());
        return Result.OK;
    }

    public Result reject(Player target) {
        return proposals.remove(target.getUniqueId()) == null ? Result.NO_PROPOSAL : Result.OK;
    }

    public GiftResult gift(Player p, String targetKey, WifeProfile wife) {
        UUID id = p.getUniqueId();
        boolean married = isSpouse(id, targetKey);
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            return fail(Result.NO_ITEM, id, targetKey, married);
        }

        String cooldownKey = id + ":" + targetKey;
        long now = System.currentTimeMillis();
        Long last = giftCooldowns.get(cooldownKey);
        if (last != null && now - last < cooldownMillis) {
            return fail(Result.GIFT_COOLDOWN, id, targetKey, married);
        }

        Material mat = hand.getType();
        String reaction;
        int delta;
        if (wife != null && wife.favoriteGifts().contains(mat)) {
            reaction = "favorite";
            delta = favPoints;
        } else if (wife != null && wife.dislikedGifts().contains(mat)) {
            reaction = "disliked";
            delta = disPoints;
        } else {
            reaction = "normal";
            delta = normalPoints;
        }

        String before = levelKey(id, targetKey, married);

        ItemStack copy = hand.clone();
        if (copy.getAmount() > 1) {
            copy.setAmount(copy.getAmount() - 1);
            p.getInventory().setItemInMainHand(copy);
        } else {
            p.getInventory().setItemInMainHand(null);
        }

        int pts = addPoints(id, targetKey, delta);
        giftCooldowns.put(cooldownKey, now);
        String after = levelKey(id, targetKey, married);
        boolean levelUp = delta > 0 && !before.equals(after);
        db.addHistory(id, "gift:" + mat.name() + ":" + targetKey, delta);
        return new GiftResult(Result.OK, reaction, delta, pts, levelUp, after);
    }

    private GiftResult fail(Result r, UUID id, String targetKey, boolean married) {
        return new GiftResult(r, "", 0, points(id, targetKey), false, levelKey(id, targetKey, married));
    }

    public Result divorce(Player p) {
        MarriageRecord rec = marriages.get(p.getUniqueId());
        if (rec == null) return Result.NOT_MARRIED;
        double debt = rec.deferredDebt();
        if (debt > 0 && (!canAfford(p, debt) || !pay(p, debt))) {
            return Result.NO_FUNDS;
        }
        if (!rec.npcSpouse()) {
            UUID other = UUID.fromString(rec.spouse());
            marriages.remove(other);
            db.deleteMarriage(other);
        }
        marriages.remove(p.getUniqueId());
        db.deleteMarriage(p.getUniqueId());
        db.addHistory(p.getUniqueId(), "divorce:" + rec.spouse(), debt);
        return Result.OK;
    }

    /** Helper for callers that need a set of keys. */
    public Set<String> levelNames() {
        return levels.keySet();
    }
}
