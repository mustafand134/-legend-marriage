package com.legend.marriage.command;

import com.legend.marriage.LegendMarriage;
import com.legend.marriage.config.MessageManager;
import com.legend.marriage.marriage.MarriageManager;
import com.legend.marriage.marriage.MarriageManager.GiftResult;
import com.legend.marriage.model.MarriageRecord;
import com.legend.marriage.model.Proposal;
import com.legend.marriage.model.WifeProfile;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MarriageCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBS = List.of(
            "بحث", "اقتراح", "قبول", "رفض", "زوجتي", "هدية", "طلاق", "مساعدة", "ادمن");

    private final LegendMarriage plugin;

    public MarriageCommand(LegendMarriage plugin) {
        this.plugin = plugin;
    }

    private MessageManager msg() {
        return plugin.messages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("legendmarriage.use")) {
            msg().send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            msg().sendList(sender, "help");
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "بحث", "search" -> handleSearch(sender);
            case "اقتراح", "propose" -> handlePropose(sender, args);
            case "قبول", "accept" -> handleAccept(sender);
            case "رفض", "reject" -> handleReject(sender);
            case "زوجتي", "wife" -> handleWife(sender);
            case "هدية", "gift" -> handleGift(sender, args);
            case "طلاق", "divorce" -> handleDivorce(sender, args);
            case "ادمن", "admin" -> handleAdmin(sender, args);
            default -> msg().sendList(sender, "help");
        }
        return true;
    }

    private Player requirePlayer(CommandSender sender) {
        if (sender instanceof Player p) {
            return p;
        }
        msg().send(sender, "player-only");
        return null;
    }

    private void handleSearch(CommandSender sender) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        if (!p.hasPermission("legendmarriage.search")) {
            msg().send(p, "no-permission");
            return;
        }
        plugin.gui().openSearch(p);
    }

    private void handlePropose(CommandSender sender, String[] args) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        if (args.length < 2) {
            msg().send(p, "usage-propose");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        WifeProfile wife = target == null ? plugin.wives().get(args[1]) : null;
        if (target == null && wife == null) {
            msg().send(p, "err.wife-not-found");
            return;
        }

        double imm;
        double def;
        try {
            imm = args.length >= 3 ? Double.parseDouble(args[2])
                    : (wife != null ? wife.minImmediate() : plugin.marriages().defaultImmediate());
            def = args.length >= 4 ? Double.parseDouble(args[3])
                    : (wife != null ? wife.minDeferred() : plugin.marriages().defaultDeferred());
        } catch (NumberFormatException e) {
            msg().send(p, "invalid-number");
            return;
        }

        if (target != null) {
            MarriageManager.Result r = plugin.marriages().proposePlayer(p, target, imm, def);
            if (r == MarriageManager.Result.OK) {
                msg().send(p, "propose.sent", "target", target.getName());
                msg().send(target, "propose.received", "proposer", p.getName(),
                        "imm", MessageManager.fmt(imm), "def", MessageManager.fmt(def));
            } else {
                msg().sendResult(p, r);
            }
        } else {
            MarriageManager.Result r = plugin.marriages().proposeNpc(p, wife, imm, def);
            if (r == MarriageManager.Result.OK) {
                msg().send(p, "marry.npc", "wife", wife.name(),
                        "imm", MessageManager.fmt(imm), "def", MessageManager.fmt(def));
            } else {
                msg().sendResult(p, r);
            }
        }
    }

    private void handleAccept(CommandSender sender) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        Proposal pr = plugin.marriages().pendingProposal(p.getUniqueId());
        if (pr == null) {
            msg().sendResult(p, MarriageManager.Result.NO_PROPOSAL);
            return;
        }
        MarriageManager.Result r = plugin.marriages().accept(p);
        if (r != MarriageManager.Result.OK) {
            msg().sendResult(p, r);
            return;
        }
        String proposerName = plugin.marriages().displayName(pr.proposer().toString());
        msg().send(p, "marry.player", "a", proposerName, "b", p.getName());
        Player proposer = Bukkit.getPlayer(pr.proposer());
        if (proposer != null) {
            msg().send(proposer, "marry.player", "a", proposerName, "b", p.getName());
        }
    }

    private void handleReject(CommandSender sender) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        Proposal pr = plugin.marriages().pendingProposal(p.getUniqueId());
        MarriageManager.Result r = plugin.marriages().reject(p);
        if (r != MarriageManager.Result.OK) {
            msg().sendResult(p, r);
            return;
        }
        msg().send(p, "propose.rejected");
        Player proposer = Bukkit.getPlayer(pr.proposer());
        if (proposer != null) {
            msg().send(proposer, "propose.rejected-proposer", "target", p.getName());
        }
    }

    private void handleWife(CommandSender sender) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        plugin.gui().openOwn(p);
    }

    private void handleGift(CommandSender sender, String[] args) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        if (!p.hasPermission("legendmarriage.gift")) {
            msg().send(p, "no-permission");
            return;
        }

        String key;
        WifeProfile wife;
        if (args.length >= 2) {
            Player tp = Bukkit.getPlayerExact(args[1]);
            if (tp != null) {
                key = tp.getUniqueId().toString();
                wife = null;
            } else {
                wife = plugin.wives().get(args[1]);
                if (wife == null) {
                    msg().send(p, "err.wife-not-found");
                    return;
                }
                key = wife.id();
            }
        } else {
            MarriageRecord rec = plugin.marriages().get(p.getUniqueId());
            if (rec == null) {
                msg().send(p, "usage-gift");
                return;
            }
            key = rec.spouse();
            wife = plugin.wives().get(key);
        }

        GiftResult g = plugin.marriages().gift(p, key, wife);
        msg().sendGift(p, g, plugin.marriages().displayName(key));
    }

    private void handleDivorce(CommandSender sender, String[] args) {
        Player p = requirePlayer(sender);
        if (p == null) return;
        MarriageRecord rec = plugin.marriages().get(p.getUniqueId());
        if (rec == null) {
            msg().sendResult(p, MarriageManager.Result.NOT_MARRIED);
            return;
        }
        String debt = MessageManager.fmt(rec.deferredDebt());
        if (args.length < 2 || !(args[1].equalsIgnoreCase("تأكيد") || args[1].equalsIgnoreCase("confirm"))) {
            msg().send(p, "divorce.confirm", "debt", debt);
            return;
        }
        MarriageManager.Result r = plugin.marriages().divorce(p);
        if (r == MarriageManager.Result.OK) {
            msg().send(p, "divorce.done", "debt", debt);
        } else {
            msg().sendResult(p, r);
        }
    }

    private void handleAdmin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("legendmarriage.admin")) {
            msg().send(sender, "no-permission");
            return;
        }
        if (args.length >= 2 && (args[1].equalsIgnoreCase("reload") || args[1].equals("اعادة-تحميل"))) {
            if (!sender.hasPermission("legendmarriage.reload")) {
                msg().send(sender, "no-permission");
                return;
            }
            plugin.reloadAll();
            msg().send(sender, "reload");
        } else {
            msg().send(sender, "admin-usage");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1) {
            for (String s : SUBS) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) result.add(s);
            }
        } else if (args.length == 2) {
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (sub.equals("اقتراح") || sub.equals("propose") || sub.equals("هدية") || sub.equals("gift")) {
                for (Player online : Bukkit.getOnlinePlayers()) {
                    result.add(online.getName());
                }
                for (WifeProfile w : plugin.wives().all()) {
                    result.add(w.id());
                }
            } else if (sub.equals("ادمن") || sub.equals("admin")) {
                result.add("اعادة-تحميل");
                result.add("reload");
            } else if (sub.equals("طلاق") || sub.equals("divorce")) {
                result.add("تأكيد");
                result.add("confirm");
            }
            result.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT)));
        }
        return result;
    }
}
