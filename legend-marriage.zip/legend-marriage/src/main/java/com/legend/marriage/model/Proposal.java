package com.legend.marriage.model;

import java.util.UUID;

public record Proposal(UUID proposer, double immediate, double deferred, long expiresAt) {}
