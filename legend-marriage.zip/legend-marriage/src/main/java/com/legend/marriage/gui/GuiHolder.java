package com.legend.marriage.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Marks our inventories so click handling can recognise them. */
public final class GuiHolder implements InventoryHolder {

    public enum Type { MAIN, SEARCH, WIFE_DETAIL, OWN }

    private final Type type;
    private final String data;
    private Inventory inventory;

    public GuiHolder(Type type, String data) {
        this.type = type;
        this.data = data;
    }

    public void bind(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public Type getType() { return type; }
    public String getData() { return data; }
}
