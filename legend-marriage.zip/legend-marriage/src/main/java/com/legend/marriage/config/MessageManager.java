package com.legend.marriage.config;

import com.legend.marriage.LegendMarriage;
import com.legend.marriage.marriage.MarriageManager;
import com.legend.marriage.marriage.MarriageManager.GiftResult;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.List;
import java.util.Locale;

public final class MessageManager {

    private final LegendMarriage plugin;
    private YamlConfiguration yaml = new YamlConfiguration();
    private String lang = "ar";

    public MessageManager(LegendMarriage plugin) {
        this.plugin = plugin;
    }

    public void load() {
        yaml = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "messages.yml"));
        String configured = plugin.getConfig().getString("language", "ar").toLowerCase(Locale.ROOT);
        lang = configured.equals("en") ? "en" : "ar";
    }

    public static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    public static String fmt(double value) {
        return String.format(Locale.US, "%.2f", value);
    }

    public String get(String key, String... kv) {
        String text = yaml.getString(lang + "." + key);
        if (text == null) {
            text = yaml.getString("en." + key, key);
        }
        for (int i = 0; i + 1 < kv.length; i += 2) {
            text = text.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return color(text);
    }

    public void send(CommandSender sender, String key, String... kv) {
        sender.sendMessage(get("prefix") + get(key, kv));
    }

    public void sendList(CommandSender sender, String key) {
        List<String> lines = yaml.getStringList(lang + "." + key);
        if (lines.isEmpty()) {
            lines = yaml.getStringList("en." + key);
        }
        for (String line : lines) {
            sender.sendMessage(color(line));
        }
    }

    public void sendResult(CommandSender sender, MarriageManager.Result result) {
        send(sender, result.getKey());
    }

    public void sendGift(Player player, GiftResult g, String targetName) {
        if (g.result() != MarriageManager.Result.OK) {
            sendResult(player, g.result());
            return;
        }
        String delta = g.delta() > 0 ? "+" + g.delta() : String.valueOf(g.delta());
        send(player, "gift." + g.reaction(), "target", targetName, "delta", delta);
        if (g.levelUp()) {
            send(player, "gift.level-up", "level", get("level." + g.levelKey()));
        }
    }
}
